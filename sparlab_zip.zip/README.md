# Sparbot
Announcement/Quick tutorial: https://youtu.be/dNGuPuy-__c

App with built-in tools to control your opponent AI in Steam fighting games (Street Fighter, Tekken, Dragonball Fighter-Z, etc.)

*Note: Has only been tested on Windows 10*

Gamers: help us make Sparbot better by testing it on your system and providing us with feedback!
Developers/Engineers: we highly value contributions! 

Features: 

- Action Editor: add and edit customizable btn/analog actions, fixed/random delays, etc. to your sequences. Also insert pre-made
                  sequences into main sequence.	
- Sequence Manager: a container for all of your action sequences. 
- Hotkeys: set your hotkeys for using during Main-Menu Mode & Training Mode
- Reps: how many times you want your sequence to play through in a set.
- Sets: how many parts your training session is divided by. 
- Main-Menu Mode: control your bot's controller with basic button presses for easy navigation.
- Train Mode: allows bot to perform reps while you are operating your own controller. Automatic pauses at the end of each set. 
- Bot Controller: API for sending inputs to the Virtual XBOX 360 Controller assigned to your "bot".
 
Why Sparbot is a better solution than built-in recorders in today's Fighting Games:

- More control over timings of inputs, allowing for more accurate outcomes when trying to get your bot to perform certain actions.
- Sequences are saved in-app, no more having to re-input settings for your AI every time you change characters or games. 
- You can save as many sequences as you want. 

Build: 
1) Have Python 32-bit (x86) or 64-bit (x86-64) installed, Sparbot has only been tested on version 3.6.5 but it may  work on others as well.
 - Installation tutorial: https://realpython.com/installing-python/ 
 - If the above link doesn't work, there are very good tutorials on YouTube.

2) Next, you need to install the virtual bus driver (by Benjamin Höglinger) so that the Bot Controller has something to plug into. Unzip the folder "installers", go to where the Scpvbus files are, open admin command prompt, enter 'cd *PATH TO FILES INSERTED HERE*' 
  - To install: 'devcon.exe install ScpVBus.inf Root\ScpVBus' 
  - To uninstall:'devcon.exe remove Root\ScpVBus' 

3) Verify that you have Microsoft Visual Studio Community 2017 installed.
  -https://visualstudio.microsoft.com/downloads/
  
4) Have the following packages installed: pillow, and cx_Freeze (if you want to build the app into executable or distributable) 
  - in Windows Powershell, "pip install pillow", "pip install cx_Freeze" 
  
5) Clone or download the zip to this repository (green button at top-right hand corner of repo main page)
  - Export the zip in a location you can easily access, such as your Desktop. 

6) To run the app:
  1) Open Windows Powershell inside the Sparbot folder (verify that there is a file named 'sparbot.py' in the folder)
  2) Enter "python sparbot.py" 

7) To build an executable, open Powershell in Sparbot's main path. Type 'python .\setup.py build' to create the .exe 

8) To build a distributable, do the same thing as in step 7 except type 'python .\setup.py bdist_msi' (This only works on Windows)

For the Bot Controller to work, game has to be played in Big Picture Mode and make sure XBOX Configuration Support is checked inside of the Big Picture Controller Settings. 


Please submit your issue if you have any problems! We will respond to you and work on a solution as quickly as possible.

Please use Sparbot responsibly. Sparbot is meant to be used for training purposes, not for cheating. If you want to minimize the risk of your license being revoked from game developers, we suggest you only use Sparbot offline.

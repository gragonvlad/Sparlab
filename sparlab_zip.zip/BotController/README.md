# vXboxInterface
API for virtual Xbox devices on ScpVBus
